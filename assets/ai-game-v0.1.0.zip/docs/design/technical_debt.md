# Technical debt (initial)

- No established constants module yet; gameplay tuning values should be moved to a central constants file.
- Project scaffolding: CI and packaging pipelines are TODO (Phase 2).
- Tests: unit test coverage for core puzzle logic is incomplete; add focused tests for time-manipulation mechanics.

