const http = require('http');
const fs = require('fs');
const path = require('path');

const SRC_DIR = path.join(process.cwd(), 'src');
const RENDER_DIR = path.join(SRC_DIR, 'render');
const INPUT_DIR = path.join(SRC_DIR, 'input');
const PORT = process.env.PORT || 3000;

const mime = { js: 'application/javascript', html: 'text/html', css: 'text/css' };

const server = http.createServer((req, res) => {
  const url = req.url || '/';
  if (url === '/' || url === '/index.html') {
    const indexPath = path.join(RENDER_DIR, 'index.html');
    if (fs.existsSync(indexPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(fs.readFileSync(indexPath, 'utf8'));
      return;
    }
  }

  if (url.startsWith('/render/') || url.startsWith('/input/')) {
    const rel = url.replace(/^\//,'');
    const filePath = path.join(SRC_DIR, rel);
    if (fs.existsSync(filePath)) {
      const ext = path.extname(filePath).slice(1);
      res.writeHead(200, { 'Content-Type': mime[ext] || 'application/octet-stream' });
      res.end(fs.readFileSync(filePath));
      return;
    }
  }

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

server.listen(PORT, () => {
  console.log(`Prototype server running at http://localhost:${PORT}/`);
});
