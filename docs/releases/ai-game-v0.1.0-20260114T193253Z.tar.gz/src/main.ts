// Start the simple static server for the prototype
const path = require('path');
require(path.join(__dirname, 'render', 'start-server.js'));
