// Core game loop with explicit state machine and fixed timestep
import { createAudioManager } from './audioManager.js';
let audio: any = null;
const TARGET_FPS = 60;
const FIXED_TIMESTEP_MS = Math.round(1000 / TARGET_FPS);

// Named durations (in ticks) to avoid magic numbers
const MENU_DURATION_TICKS = TARGET_FPS * 1; // 1 second
const PLAY_DURATION_TICKS = TARGET_FPS * 60; // 60 seconds
const PAUSE_DURATION_TICKS = TARGET_FPS * 1; // 1 second
const GAMEOVER_DURATION_TICKS = TARGET_FPS * 1; // 1 second

// Gameplay timing constants
const PLAYER_HEALTH_DECAY_TICKS = TARGET_FPS * 5; // player loses 1 HP every 5 seconds (slower decay for pacing)
const FEEDBACK_DURATION_TICKS = Math.round(TARGET_FPS * 0.5); // feedback visible ~0.5s

// Inventory constants
const INVENTORY_MAX_SLOTS = 10;

// Currency and shop constants
const STARTING_COINS = 20;
const MEDKIT_PRICE = 5;
const AMMO_PRICE = 3;
const SELL_MULTIPLIER = 0.5;

enum GamePhase {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
  GAME_OVER = 'GAME_OVER',
}

type InventoryItem = { id: string; name: string; count: number };

type PlayerState = {
  health: number;
  maxHealth: number;
  score: number;
  ammo: number;
  gold: number;
  inventory: InventoryItem[];
};

type Feedback = {
  text: string | null;
  ticksLeft: number;
};

type GameState = {
  phase: GamePhase;
  tick: number; // global tick counter
  phaseTick: number; // ticks elapsed in current phase
  running: boolean;
  player: PlayerState;
  feedback: Feedback;
};

const INITIAL_STATE: GameState = {
  phase: GamePhase.MENU,
  tick: 0,
  phaseTick: 0,
  running: true,
  player: { health: 10, maxHealth: 10, score: 0, ammo: 0, gold: 50, inventory: [] },
  feedback: { text: null, ticksLeft: 0 },
};

function transitionTo(state: GameState, phase: GamePhase): GameState {
  return { ...state, phase, phaseTick: 0 };
}

function addItemToInventory(state: GameState, item: { id: string; name: string; count?: number }): GameState {
  const it = { id: item.id, name: item.name, count: item.count ?? 1 };
  const playerInv = [...state.player.inventory];
  const idx = playerInv.findIndex(i => i.id === it.id);
  if (idx >= 0) {
    playerInv[idx] = { ...playerInv[idx], count: playerInv[idx].count + it.count };
  } else {
    if (playerInv.length < INVENTORY_MAX_SLOTS) playerInv.push(it);
    else return { ...state, feedback: { text: 'Inventory Full', ticksLeft: FEEDBACK_DURATION_TICKS } };
  }
  return { ...state, player: { ...state.player, inventory: playerInv }, feedback: { text: `Picked up ${it.name}`, ticksLeft: FEEDBACK_DURATION_TICKS } };
}

function useItemFromInventory(state: GameState, itemId: string): GameState {
  const playerInv = [...state.player.inventory];
  const idx = playerInv.findIndex(i => i.id === itemId);
  if (idx < 0) return { ...state, feedback: { text: 'No such item', ticksLeft: FEEDBACK_DURATION_TICKS } };
  const item = playerInv[idx];
  let updatedPlayer = { ...state.player };
  if (item.id === 'medkit') {
    updatedPlayer = { ...updatedPlayer, health: Math.min(updatedPlayer.maxHealth, updatedPlayer.health + 2) };
  } else if (item.id === 'ammo') {
    updatedPlayer = { ...updatedPlayer, ammo: updatedPlayer.ammo + 5 };
  } else {
    updatedPlayer = { ...updatedPlayer, score: updatedPlayer.score + 10 };
  }
  if (item.count > 1) playerInv[idx] = { ...item, count: item.count - 1 };
  else playerInv.splice(idx, 1);
  updatedPlayer = { ...updatedPlayer, inventory: playerInv };
  return { ...state, player: updatedPlayer, feedback: { text: `Used ${item.name}`, ticksLeft: FEEDBACK_DURATION_TICKS } };
}

const SHOP_ITEMS = [
  { id: 'medkit', name: 'Medkit', price: 10 },
  { id: 'ammo', name: 'Ammo', price: 5 },
];

function buyItemFromShop(state: GameState, itemId: string): GameState {
  const item = SHOP_ITEMS.find(s => s.id === itemId);
  if (!item) return { ...state, feedback: { text: 'No such shop item', ticksLeft: FEEDBACK_DURATION_TICKS } };
  if (state.player.gold < item.price) return { ...state, feedback: { text: 'Not enough gold', ticksLeft: FEEDBACK_DURATION_TICKS } };
  if (state.player.inventory.length >= INVENTORY_MAX_SLOTS) return { ...state, feedback: { text: 'Inventory Full', ticksLeft: FEEDBACK_DURATION_TICKS } };
  let newState = { ...state, player: { ...state.player, gold: state.player.gold - item.price } };
  newState = addItemToInventory(newState, { id: item.id, name: item.name });
  return { ...newState, feedback: { text: `Bought ${item.name} for ${item.price}g`, ticksLeft: FEEDBACK_DURATION_TICKS } };
}

function sellFirstInventoryItem(state: GameState): GameState {
  if (state.player.inventory.length === 0) return { ...state, feedback: { text: 'Inventory empty', ticksLeft: FEEDBACK_DURATION_TICKS } };
  const item = state.player.inventory[0];
  const shopEntry = SHOP_ITEMS.find(s => s.id === item.id);
  const price = shopEntry ? Math.floor(shopEntry.price / 2) : 1;
  let updatedInv = [...state.player.inventory];
  if (item.count > 1) updatedInv[0] = { ...item, count: item.count - 1 };
  else updatedInv.splice(0,1);
  const updatedPlayer = { ...state.player, inventory: updatedInv, gold: state.player.gold + price };
  return { ...state, player: updatedPlayer, feedback: { text: `Sold ${item.name} for ${price}g`, ticksLeft: FEEDBACK_DURATION_TICKS } };
}

function update(state: GameState): GameState {
  const next: GameState = { ...state, tick: state.tick + 1, phaseTick: state.phaseTick + 1 };

  switch (state.phase) {
    case GamePhase.MENU:
      if (state.phaseTick >= MENU_DURATION_TICKS) {
        return transitionTo(next, GamePhase.PLAYING);
      }
      return next;

    case GamePhase.PLAYING:
      // Demo gameplay: periodic damage to showcase HUD and feedback cues
      const DAMAGE_INTERVAL_TICKS = PLAYER_HEALTH_DECAY_TICKS;
      let updated: GameState = { ...next } as GameState;
      if (state.phaseTick >= PLAY_DURATION_TICKS) {
        return transitionTo(updated, GamePhase.GAME_OVER);
      }

      // Apply periodic damage for demo purposes
      if (state.tick > 0 && state.tick % DAMAGE_INTERVAL_TICKS === 0) {
        updated = {
          ...updated,
          player: { ...state.player, health: Math.max(0, state.player.health - 1) },
          feedback: { text: 'Hit! -1 HP', ticksLeft: FEEDBACK_DURATION_TICKS },
        };
        if (audio) audio.playSFX('hit');
      } else {
        // decay feedback timer
        const ticksLeft = Math.max(0, state.feedback.ticksLeft - 1);
        updated = { ...updated, feedback: { text: ticksLeft > 0 ? state.feedback.text : null, ticksLeft } };
      }

      // If player died, go to GAME_OVER
      if (updated.player.health <= 0) {
        return transitionTo({ ...updated, running: true }, GamePhase.GAME_OVER);
      }
      return updated;

    case GamePhase.PAUSED:
      if (state.phaseTick >= PAUSE_DURATION_TICKS) {
        return transitionTo(next, GamePhase.PLAYING);
      }
      return next;

    case GamePhase.GAME_OVER:
      if (state.phaseTick >= GAMEOVER_DURATION_TICKS) {
        return { ...next, running: false };
      }
      return next;

    default:
      return next;
  }
}

function render(state: GameState): void {
  // Minimal textual render for headless environments; real renderers subscribe to state
  console.log(`PHASE=${state.phase} TICK=${state.tick} PHASE_TICK=${state.phaseTick}`);
}

function setupInputHandlers(handleKey: (key: string) => void): void {
  // Basic CLI input: passes raw key sequences to handler for menu and pause navigation.
  if (typeof process === 'undefined' || !process.stdin || !process.stdin.setRawMode) return;
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.on('data', (chunk: Buffer) => {
    const key = String(chunk);
    handleKey(key);
    if (key === '\u0003') { // ctrl-c
      process.exit(0);
    }
  });
}

function main(): void {
  let state = { ...INITIAL_STATE };

  // Menu definitions (named constants to avoid magic numbers)
  const mainMenuOptions = ['Start Game', 'Options', 'Exit'];
  const pauseMenuOptions = ['Resume', 'Restart', 'Exit to Menu'];
  let mainMenuIndex = 0;
  let pauseMenuIndex = 0;

  function handleKey(key: string) {
    // Toggle pause with 'p'
    if (key === 'p') {
      if (state.phase === GamePhase.PLAYING) {
        state = transitionTo(state, GamePhase.PAUSED);
      } else if (state.phase === GamePhase.PAUSED) {
        state = transitionTo(state, GamePhase.PLAYING);
      }
      return;
    }

    // Inventory shortcuts: 'c' to collect demo medkit, 'u' to use first item
    if (key === 'c') {
      state = addItemToInventory(state, { id: 'medkit', name: 'Medkit' });
      return;
    }
    if (key === 'u') {
      if (state.player.inventory.length > 0) {
        state = useItemFromInventory(state, state.player.inventory[0].id);
      } else {
        state = { ...state, feedback: { text: 'Inventory empty', ticksLeft: FEEDBACK_DURATION_TICKS } };
      }
      return;
    }

    // Menu navigation (arrow up/down sequences or w/s)
    if (state.phase === GamePhase.MENU) {
      if (key === '\u001b[A' || key === '\x1b[A' || key === 'w') {
        mainMenuIndex = (mainMenuIndex - 1 + mainMenuOptions.length) % mainMenuOptions.length;
      } else if (key === '\u001b[B' || key === '\x1b[B' || key === 's') {
        mainMenuIndex = (mainMenuIndex + 1) % mainMenuOptions.length;
      } else if (key === '\r' || key === '\n') {
        const sel = mainMenuOptions[mainMenuIndex];
        if (sel === 'Start Game') { state = transitionTo(state, GamePhase.PLAYING); if (!audio) audio = createAudioManager(); if (audio) audio.playMusic('music_theme'); }
        else if (sel === 'Exit') state = { ...state, running: false };
      }
      return;
    }

    if (state.phase === GamePhase.PLAYING) {
      // Gameplay keys: 'g' or 'c' to collect demo item, 'u' to use first item
      if (key === 'g' || key === 'c') {
        const itemId = (state.tick % 2 === 0) ? 'medkit' : 'ammo';
        const itemName = itemId === 'medkit' ? 'Medkit' : 'Ammo';
        state = addItemToInventory(state, { id: itemId, name: itemName });
      } else if (key === 'u') {
        if (state.player.inventory.length > 0) {
          state = useItemFromInventory(state, state.player.inventory[0].id);
        } else {
          state = { ...state, feedback: { text: 'Inventory empty', ticksLeft: FEEDBACK_DURATION_TICKS } };
        }
      } else if (key === 'b') {
        // buy medkit
        state = buyItemFromShop(state, 'medkit');
      } else if (key === 'n') {
        // buy ammo
        state = buyItemFromShop(state, 'ammo');
      } else if (key === 'S') {
        // sell first item
        state = sellFirstInventoryItem(state);
      }
      return;
    }

    if (state.phase === GamePhase.PAUSED) {
      if (key === '\u001b[A' || key === '\x1b[A' || key === 'w') {
        pauseMenuIndex = (pauseMenuIndex - 1 + pauseMenuOptions.length) % pauseMenuOptions.length;
      } else if (key === '\u001b[B' || key === '\x1b[B' || key === 's') {
        pauseMenuIndex = (pauseMenuIndex + 1) % pauseMenuOptions.length;
      } else if (key === '\r' || key === '\n') {
        const sel = pauseMenuOptions[pauseMenuIndex];
        if (sel === 'Resume') state = transitionTo(state, GamePhase.PLAYING);
        else if (sel === 'Restart') state = transitionTo({ ...INITIAL_STATE, tick: state.tick }, GamePhase.PLAYING);
        else if (sel === 'Exit to Menu') state = transitionTo({ ...INITIAL_STATE, running: true }, GamePhase.MENU);
      }
      return;
    }
  }

  setupInputHandlers(handleKey);

  function renderUI() {
    if (state.phase === GamePhase.MENU) {
      console.clear();
      console.log('=== MAIN MENU ===');
      mainMenuOptions.forEach((opt, i) => {
        console.log((i === mainMenuIndex ? '> ' : '  ') + opt);
      });
    } else if (state.phase === GamePhase.PAUSED) {
      console.log('=== PAUSED ===');
      pauseMenuOptions.forEach((opt, i) => {
        console.log((i === pauseMenuIndex ? '> ' : '  ') + opt);
      });
    } else if (state.phase === GamePhase.PLAYING) {
      // HUD display
      const p = state.player;
      const filled = Math.max(0, Math.min(p.maxHealth, p.health));
      const healthBar = '[' + '#'.repeat(filled) + '-'.repeat(Math.max(0, p.maxHealth - filled)) + ']';
      console.log(`HUD: Health ${healthBar} (${p.health}/${p.maxHealth}) Score: ${p.score} Ammo: ${p.ammo} Gold: ${p.gold}`);
      if (state.feedback.text) {
        console.log(`>> ${state.feedback.text}`);
      }
      // Inventory UI
      if (p.inventory && p.inventory.length > 0) {
        console.log('Inventory:');
        p.inventory.forEach((it, i) => console.log(`  ${i + 1}. ${it.name} x${it.count}`));
      } else {
        console.log('Inventory: (empty)');
      }
    }
  }

  const interval = setInterval(() => {
    state = update(state);
    render(state);
    renderUI();

    if (!state.running) {
      clearInterval(interval);
      console.log('Game loop finished: exiting');
      process.exit(0);
    }
  }, FIXED_TIMESTEP_MS);
}

main();
